# AI Based Trading System

This code works as a boilerplate for an AI based trading system with yfinance as data source and RobinHood or Alpaca as brokers. DO NOT USE IT FOR TRADING AS IT IS. Follow [the tutorial in Medium.](https://towardsdatascience.com/how-to-create-a-fully-automated-ai-based-trading-system-with-python-708503c1a907)

Since I plan to keep writing on this topic I'm moving the original boilerplate to the `original_boilerplate` folder - without removing anything. I'll keep the `ai-trading-system` folder polished and more production-ready.

Usage so far:

```
$ sudo dockerd
$ docker-compose up --build ai-trading-system
```

Stay tuned!
